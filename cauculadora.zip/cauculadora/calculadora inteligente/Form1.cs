namespace calculadora_inteligente;

public partial class Form1 : Form
{
    private double result = 0;
    private string operation = string.Empty;
    private bool isOperationPerformed = false;

    public Form1()
    {
        InitializeComponent();
    }

    private void CalculateButton_Click(object? sender, EventArgs e)
    {
        // Implementar a lógica de cálculo aqui
        string[] inputs = displayTextBox.Text.Split(new char[] { '+', '-', '*', '/' });
        if (inputs.Length == 2)
        {
            double num1 = double.Parse(inputs[0]);
            double num2 = double.Parse(inputs[1]);
            switch (operation)
            {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
                case "/":
                    result = num1 / num2;
                    break;
                default:
                    MessageBox.Show("Operação inválida.");
                    return;
            }
            displayTextBox.Text = result.ToString();
        }
        else
        {
            MessageBox.Show("Por favor, insira uma operação válida.");
        }
    }

    private void NumberButton_Click(object? sender, EventArgs e)
    {
        if (sender is Button button)
        {
            if (displayTextBox.Text == "0" || isOperationPerformed)
                displayTextBox.Clear();

            isOperationPerformed = false;
            displayTextBox.Text += button.Text;
        }
    }

    private void OperationButton_Click(object? sender, EventArgs e)
    {
        if (sender is Button button)
        {
            operation = button.Text;
            result = double.Parse(displayTextBox.Text);
            isOperationPerformed = true;
        }
    }

    private void ClearButton_Click(object? sender, EventArgs e)
    {
        displayTextBox.Text = "0";
        result = 0;
        operation = string.Empty;
    }
}
