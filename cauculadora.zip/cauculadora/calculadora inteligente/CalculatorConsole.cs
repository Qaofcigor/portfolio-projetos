using System;

namespace calculadora_inteligente
{
    class CalculatorConsole
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculadora Simples");
            Console.WriteLine("Digite o primeiro número:");
            double num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Digite a operação (+, -, *, /):");
            string operation = Console.ReadLine();

            Console.WriteLine("Digite o segundo número:");
            double num2 = Convert.ToDouble(Console.ReadLine());

            double result = 0;

            switch (operation)
            {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
                case "/":
                    result = num1 / num2;
                    break;
                default:
                    Console.WriteLine("Operação inválida.");
                    return;
            }

            Console.WriteLine($"Resultado: {result}");
        }
    }
}
