﻿﻿namespace calculadora_inteligente;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;
    private System.Windows.Forms.TextBox displayTextBox;
    private System.Windows.Forms.Button calculateButton;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        this.components = new System.ComponentModel.Container();
        this.displayTextBox = new System.Windows.Forms.TextBox();
        this.calculateButton = new System.Windows.Forms.Button();

        // 
        // Form1
        // 
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(400, 200);
        this.Controls.Add(this.displayTextBox);
        this.Controls.Add(this.calculateButton);
        this.Text = "Calculadora Simples";

        // 
        // displayTextBox
        // 
        this.displayTextBox.Location = new System.Drawing.Point(12, 12);
        this.displayTextBox.Size = new System.Drawing.Size(360, 40);
        this.displayTextBox.ReadOnly = false;

        // 
        // calculateButton
        // 
        this.calculateButton.Text = "Calcular";
        this.calculateButton.Location = new System.Drawing.Point(150, 70);
        this.calculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
    }
}
