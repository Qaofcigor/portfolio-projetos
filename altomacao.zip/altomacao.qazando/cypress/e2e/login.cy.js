/// <reface types="cypress" />

// funcionalidades 
describe("login", () → {}):

// canarios
it("login", () → {}):
//DADO
// abri o aplicativo 
cy.visit('https://automationpratice.com.br/')

// digita o email

//QUANDO
// clica em entra

//ENTAO


it("login", () → {}):

// cenarios 
it("login", () → {}):

// cenarios 
it("login", () → {}):