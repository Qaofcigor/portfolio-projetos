# Projeto de Testes Automatizados com Selenium e Java

Este projeto utiliza Java, Maven, Selenium WebDriver e JUnit para realizar testes automatizados no site [The Internet - Login](https://the-internet.herokuapp.com/login).

## Estrutura do Projeto

- `pom.xml`: Configuração do Maven e dependências.
- `src/test/java/pages`: Classes que representam as páginas da aplicação (Page Object Model).
- `src/test/java/tests`: Classes de teste que utilizam as páginas para realizar os testes.
- `src/test/resources`: Recursos adicionais para os testes.

## Como Executar

1. Certifique-se de ter o Java e o Maven instalados.
2. No terminal, navegue até a pasta do projeto.
3. Execute os testes com o comando:
   ```
   mvn test
   ```

## Dependências

- Selenium Java 4.20.0
- JUnit Jupiter 5.10.2

## Contato

Desenvolvido por Igor Santiago.
