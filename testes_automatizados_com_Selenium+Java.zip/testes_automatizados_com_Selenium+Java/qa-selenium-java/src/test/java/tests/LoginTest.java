package tests;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.LoginPage;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class LoginTest {
    private WebDriver driver;
    private LoginPage loginPage;

    @BeforeEach
    public void setUp() {
        // Configurar o caminho do driver do Chrome conforme seu ambiente
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://the-internet.herokuapp.com/login");
        loginPage = new LoginPage(driver);
    }

    @Test
    public void testLoginComSucesso() {
        loginPage.login("tomsmith", "SuperSecretPassword!");
        String mensagem = loginPage.getFlashMessage();
        assertTrue(mensagem.contains("You logged into a secure area!"));
    }

    @Test
    public void testLoginComFalha() {
        loginPage.login("usuario_invalido", "senha_errada");
        String mensagem = loginPage.getFlashMessage();
        assertTrue(mensagem.contains("Your username is invalid!"));
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
