﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}