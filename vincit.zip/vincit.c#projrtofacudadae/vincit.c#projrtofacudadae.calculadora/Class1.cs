﻿namespace vincit.c_projrtofacudadae.calculadora;

public class Class1
{

}
